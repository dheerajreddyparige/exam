package com.cg.sessionschedulemanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sessionschedulemanagementsystem.beans.SessionSchedule;
import com.cg.sessionschedulemanagementsystem.service.ISessionService;



@Controller
public class SessionController {

	@Autowired
	ISessionService sessionservice;
	
	
	
	/*
	 * This function will call the service layer method and return jsp page
	 * it is being called by index.jsp 
	 * Also it returns the list with key="data" to jsp page
	 */
	
	@RequestMapping(value="/scheduledsessions",method=RequestMethod.GET)
	public ModelAndView getAllSessions(){
		
		List<SessionSchedule> allSessionsList=sessionservice.getSessionSchedule();
		System.out.println(allSessionsList);	//to check whether list is obtained or not. it displays list in console											
		
		
		return new ModelAndView("scheduledsessions", "data", allSessionsList);
	}
	
	

	/*
	 * This function return jsp page
	 * it is being called by scheduledsessions.jsp  
	 * Also it returns a string with key="data" to jsp page
	 */
	
	@RequestMapping(value="/Success")
	public ModelAndView dispPurchase(@RequestParam("sessName") String sn){
		
		System.out.println(sn);			//to check whether String is obtained or not. it displays String in console	
		
		return new ModelAndView("success", "data",sn);
	}
}
