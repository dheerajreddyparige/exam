package com.cg.sessionschedulemanagementsystem.dao;

import java.util.List;

import com.cg.sessionschedulemanagementsystem.beans.SessionSchedule;

public interface ISessionDao {
	
	public List<SessionSchedule> getSessionSchedule();
		

}
